<?php
header('Location: /sistema'); 
?>