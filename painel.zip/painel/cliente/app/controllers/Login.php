<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Login extends CI_Controller {

    function index() {
        $this->load->view("Login/Login.index.php");
    }

    function logar() {

        $this->load->model("User_Model", "User");
        $this->load->model("Profile_Model", "Profile");

        $user = $this->User->getByLoginPass($_POST['login'], $_POST['password']);

        if ($user !== false) {

            $user['profile_string'] = null;            
            arrayToString(",", $this->Profile->getProfilesBySerialize($user['profiles']), $user['profile_string']);
            
            $user['autenticado'] = true;
            $this->session->set_userdata($user);

            redirect('principal/index');
        }
        $this->session->set_flashdata('msg', '<div class="alert alert-danger">Falha de Autenticação. Login e/ou Senha informados incorretamente.</div>');

        exit('<script>'
                . 'window.history.go(-1);'
                . '</script>'
        );
    }

    function logout() {
        $this->session->sess_destroy();
        redirect('login/entrar');
    }

    function teste(){
        $this->load->helper("MY_comum_helper");
        
        $profiles[0] = array('name'=>'claro');
        $profiles[1] = array('name'=>'ceu');   
        
        
      
        
        var_dump(arrayToString_V2(",",$profiles));
    }
}
