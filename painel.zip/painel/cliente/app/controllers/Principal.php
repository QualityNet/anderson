<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Principal extends MY_Controller {

    function index() {

        $dados_topo["subtitulo"] = "Principal";

        $this->load->model("Transacao_Model", "Transacao");

        $user = $this->session->userdata;

        $this->Transacao->getAllByLogin($user['id'], isset($this->uri->segments[3]) ? $this->uri->segments[3] : 1);

        $this->load->library('adapter_transacao');

        $this->load->helper('MY_upload_helper');

        $this->load->library('pagination');

        $config['base_url'] = base_url("index.php/principal/index");
        $config['total_rows'] = @$this->Transacao->paginacao->total_rows;
        $config['per_page'] = & $this->Transacao->paginacao->por_pagina;
        $config['display_pages'] = TRUE;
        $config['use_page_numbers'] = TRUE;
        $config['uri_segment'] = 3;

        $this->pagination->initialize($config);


        $dados_corpo['page_links'] = $this->pagination->create_links();


        $dados_corpo['transacoes'] = @$this->Transacao->paginacao->dados;
        $dados_corpo['adapter_trans'] = $this->adapter_transacao;


        $this->load->view("Comum/Comum.topo.php", $dados_topo);
        $this->load->view("Comum/Comum.menu.php");
        $this->load->view("Principal/Principal.index.php", $dados_corpo);
        $this->load->view("Comum/Comum.rodape.php");
    }

    function add_pagamento() {

        $dados_topo["subtitulo"] = "Pagamentos";

        $this->load->view('Comum/Comum.topo.php', $dados_topo);
        $this->load->view("Principal/Principal.add_pagamento.php");
    }

    function save_pagamento() {
        
    }

    function upload_arquivo() {
        
    }

    function alterar_senha() {
        var_dump($_POST);
    }

    function upload() {
        echo "<pre>";
        var_dump($_FILES);
        echo "</pre>";
        exit();
    }

    function teste_sessao() {
        var_dump($this->session->all_userdata());
        echo "-----<br/>";
        var_dump($_SESSION);
    }

    function teste_adpt() {
        $this->load->library('adapter_transacao');
        $this->adapter_transacao->setTransacao(array('status' => 3));
        echo $this->adapter_transacao->getStatusString();
        $this->adapter_transacao->setTransacao(array('status' => 4, 'data_cad' => '2015-02-15 21:14:36'));
        echo $this->adapter_transacao->getStatusString();
        echo $this->adapter_transacao->getDataCad_BR();
    }

    function teste_trans() {
        $tipo[1] = 'Pagseguro';
        $tipo[2] = 'Boleto Facil';
        $tipo[3] = 'Deposito/TEV';

        $int_tipo = "1";

        var_dump(array_key_exists($int_tipo, $tipo));
    }

    function teste_trans2() {
        $this->load->model("Transacao_Arquivo_Model", "Transacao_Arquivo");


        $trans = $this->Transacao_Arquivo->remove(2, 0);
        var_dump($trans);
    }

    function teste_func() {

        //echo require_once __DIR__ . '/../../../includes/functions.php';
        //echo "<br/>";

        require_once INC_GLOBAL . DIRECTORY_SEPARATOR . 'functions.php';

        //$saldo_pre = saldo_revenda_pre(443);
        //var_dump($saldo_pre);
        //$user = $this->session->userdata;

        /* echo "<pre>";
          var_dump($user['addedby']);
          echo "</pre>"; */
    }

    function teste_path() {

        echo require_once PATH_GLOBAL . DIRECTORY_SEPARATOR . 'config.php';
    }

}
