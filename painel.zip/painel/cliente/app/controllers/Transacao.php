<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Transacao extends MY_Controller {

    function save_transacao() {

        /*
          id	int(11)	Não
          id_user	int(11)	Não // sessao
          id_revenda	int(11)	Não // sessao
          tipo	int(11)	Não /1-pagseguro,2-Boleto Facil 3-deposito
          valor_un	decimal(10,0)	Não
          qtd_meses	int(11)	Não
          valor_total	decimal(10,0)	Não
          data_cad	datetime	Não
          data_atualizacao	datetime	Não
          status 	int(11)	Não 1-aberto, 2-aguardando pagamento, 3-aprovado , 4-fechado
         */

        $this->load->model('Transacao_Model', 'Transacao');


        $user = $this->session->userdata;


        //pega o valor do banco

        $rs = $this->db->query("SELECT valor_cob,email FROM cmum_udb WHERE id = {$user['id']} AND addedby = {$user['addedby']}");
        
        $row = $rs->row_array();

        if ($rs->num_rows() == 0 || $row['valor_cob'] == 0 || $row['email'] == "") {

            $js = <<<js
        <script>
            alert('Ocorreu um erro interno você não poderá continuar com esta operação.');
            window.history.go(-1);
        </script>       
js;
            exit($js);
        }        
        

        $dados_login_bd = $rs->row_array();


        require_once INC_GLOBAL . DIRECTORY_SEPARATOR . 'debug.php';
        require_once INC_GLOBAL . DIRECTORY_SEPARATOR . 'functions.php';


        $dados_revenda = dados_revenda($user['addedby'], "*");

        $rev_pre = (int) $dados_revenda['rev_pre'];



        // verifica se a revenda tem saldo para iniciar uma nova cobrança.
        // pos pagas
        if ($rev_pre == 0) {

            $saldo_rev_pos = saldo_revenda2($user['addedby']);

            if ($saldo_rev_pos <= 0) {

                $js = <<<js
        <script>
            alert('A Revenda não tem saldo suficiente pra liberação. Escolha uma quantidade menor em meses ou entre em contato com seu revendedor!');
            window.history.go(-1);
        </script>       
js;
                exit($js);
            }
        }
        //pre pagas
        if ($rev_pre == 1) {

            $_saldo_revenda_pre = saldo_revenda_pre($user['addedby']);
            $saldo_revenda_pre = $_saldo_revenda_pre[$user['addedby']];

            // verifica o saldo de revendas pre pagas
            if ($saldo_revenda_pre['saldo_real'] < ((int) $_POST['qtd_meses']) || $saldo_revenda_pre['saldo_real'] <= 0) {

                $js = <<<js
        <script>
            alert('A Revenda não tem saldo suficiente pra liberação. Escolha uma quantidade menor em meses ou entre em contato com seu revendedor!');
            window.history.go(-1);
        </script>       
js;
                exit($js);
            }
        }

        $transacao['id_user'] = $user['id'];
        $transacao['id_revenda'] = $user['addedby'];
        $transacao['tipo'] = $_POST['tipo_renovacao'];
        $transacao['valor_un'] = $dados_login_bd['valor_cob'];
        $transacao['qtd_meses'] = $_POST['qtd_meses'];
        $transacao['valor_total'] = number_format($transacao['qtd_meses'] * $transacao['valor_un'], 2);
        $transacao['data_cad'] = date('Y-m-d H:i:s');
        $transacao['detalhes'] = "<p><strong>Valor un.:</strong> R$ {$transacao['valor_un']}<br/><strong>Qtd Meses:</strong> {$_POST['qtd_meses']}<br/><strong>Total:</strong> R$ {$transacao['valor_total']}</p>";
        $transacao['status'] = 1; // aberta
        //dados extras boleto facil
        $dados_extras['nome_fantasia'] = $_POST['nome_fantasia'];
        $dados_extras['is_cnpj'] = isset($_POST['is_cpnj']) ? true : false;
        $dados_extras['cpf_cnpj'] = preg_replace('/[^0-9]/', '', $_POST['cpf_cnpj']);

        //verifica se é do tipo boleto facil
        if ($transacao['tipo'] == '2') {

            if ($dados_extras['nome_fantasia'] == "" || $dados_extras['cpf_cnpj'] == "") {

                $js = <<<EOF
                         <script>
                            alert('Nome/Fantasia e ou CPF/CNPJ são obrigatórios.');
                            window.history.go(-1);
                         </script>                          
EOF;
                exit($js);
            }

            //carregando validação de cpf e cnpj
            $this->load->library('valida_cpf_cnpj', array('valor' => $dados_extras['cpf_cnpj']));

            //validando documentos

            if (!$this->valida_cpf_cnpj->valida()) {

                $javascript = <<< EOF
                 <script>
                    alert('O CPF/CNPJ Informado é inválido');
                    window.history.go(-1);
                 </script>                
EOF;
                exit($javascript);
            }
        }

        //exit('passou');
        //cria nova transação e pagamento
        if ($this->Transacao->save($transacao)) {

            // pagseguro
            if ($transacao['tipo'] == 1) {

                $dados_revenda = dados_revenda($transacao['id_revenda'], 'email_ps,token_ps');

                $dados_pagamento_ps['url_notificacao'] = url_exibivel_painel('notificacao_ps.php?r=' . base64_url_encode(ept($transacao['id_revenda'], $s)));
                $dados_pagamento_ps['desc_produto'] = 'Renovacoes servicos web';
                $dados_pagamento_ps['qtd'] = $transacao['qtd_meses'];
                $dados_pagamento_ps['valor_un'] = $transacao['valor_un'];
                $dados_pagamento_ps['id_referencia'] = base64_encode(json_encode(array('tipo' => 'L', 'id' => $this->Transacao->ultimo_id_inserido)));
                $dados_pagamento_ps['email_ps_rev'] = $dados_revenda['email_ps'];
                $dados_pagamento_ps['token_ps_rev'] = $dados_revenda['token_ps'];
                
                //var_dump($dados_pagamento_ps);exit();
                
                $url = cria_pagamento_ps($dados_pagamento_ps);
                
                
            }

            //boleto facil
            if ($transacao['tipo'] == 2) {

                $dados_revenda = dados_revenda($transacao['id_revenda'], 'email_bf,token_bf');

                $dados_pagamento['token'] = $dados_revenda['token_bf'];
                $dados_pagamento['desc_produto'] = 'Renovacoes servicos web';
                $dados_pagamento['id_referencia'] = base64_encode(json_encode(array('tipo' => 'L', 'id' => $this->Transacao->ultimo_id_inserido)));
                $dados_pagamento['valor_total'] = $transacao['valor_total'];
                $dados_pagamento['nome_cliente'] = $dados_extras['nome_fantasia'];
                $dados_pagamento['cpf_cpnj_cliente'] = $dados_extras['cpf_cnpj'];
                $dados_pagamento['email_cliente'] = $dados_login_bd['email'];

                //var_dump($dados_pagamento);exit();

                $url_bf = cria_pagamento_bf($dados_pagamento);

                $retorno = retorno_bf($url_bf);

                if ($retorno->sucesso == true) {

                    // link do boleto
                    $url = $retorno->dados['data']['charges'][0]['link'];

                    $js = <<<js
                        <script>
                            alert('Dados da transação salvos com sucesso. Clique em Ok para baixar o seu boleto.');
                            window.open('$url');
                            //window.close();
                        </script>   
js;
                    exit($js);
                }
            }

            //deposito
            if ($transacao['tipo'] == 3) {

                $url = url_exibivel_painel("informacoes_bancarias.php?r=" . base64_url_encode(ept($transacao['id_revenda'], $s)) . '&d=' . base64_url_encode(json_encode($transacao)));
            }

            $js = <<<js
                    <script>
                        alert('Dados da transação salvos com sucesso. Clique em Ok para continuar para pagina de pagamento.');
                        window.open('$url');
                        window.close();
                    </script>       
js;
            exit($js);
        }
    }

}
