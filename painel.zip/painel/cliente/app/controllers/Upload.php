<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Upload extends MY_Controller {

    function index($id = null) {

        $dados_topo["subtitulo"] = "Upload";
        $dados_corpo["transacao_id"] = $id;

        $this->load->view('Comum/Comum.topo.php', $dados_topo);
        $this->load->view("Principal/Principal.upload_arquivo.php", $dados_corpo);
    }

    function save_upload($id = null) {

        $config['upload_path'] = BASEPATH . '/../uploads/';
        $config['allowed_types'] = 'gif|jpg|jpeg|png|pdf';
        $config['max_size'] = '2000';
        $config['encrypt_name'] = TRUE;
        //$config['max_width'] = '1024';
        //$config['max_height'] = '768';

        $this->load->library('upload', $config);

        if (!$this->upload->do_upload()) {

            $erros = array('error' => $this->upload->display_errors('<p>', '</p>'));

            $string_erro = "";

            foreach ($erros as $erro) {
                $string_erro .= $erro;
            }

            $dados_arquivo = $this->upload->data();

            $this->session->set_flashdata('msg', '<div class="alert alert-danger">' . $string_erro . '</div>');

            exit(
                    '<script>'
                    . 'window.history.go(-1);'
                    . '</script>'
            );
        } else {
            /*
              Coluna	Tipo	Nulo	Predefinido	Comentários	MIME
              id	int(11)	Não
              id_login	int(11)	Não
              id_transacao	int(11)	Não
              nome_arquivo	varchar(255)	Não
              caminho_completo_arquivo	varchar(255)	Não
              is_image	tinyint(4)	Não
              extensao	int(11)	Não
              data_cad
             * 
             *  dados do upload
              Array
              (
              [file_name]     => mypic.jpg
              [file_type]     => image/jpeg
              [file_path]     => /path/to/your/upload/
              [full_path]     => /path/to/your/upload/jpg.jpg
              [raw_name]      => mypic
              [orig_name]     => mypic.jpg
              [client_name]   => mypic.jpg
              [file_ext]      => .jpg
              [file_size]     => 22.2
              [is_image]      => 1
              [image_width]   => 800
              [image_height]  => 600
              [image_type]    => jpeg
              [image_size_str] => width="800" height="200"
              )
             */

            $dados_arquivo = $this->upload->data();

            $this->load->model("Transacao_Arquivo_Model", "Transacao_Arquivo");

            $user = $this->session->userdata;

            $transacao_arquivo['id_login'] = $user['id'];
            $transacao_arquivo['id_transacao'] = $_POST['transacao_id'];
            $transacao_arquivo['nome_arquivo_salvo'] = $dados_arquivo['file_name'];
            $transacao_arquivo['nome_arquivo_orig'] = $dados_arquivo['orig_name'];
            $transacao_arquivo['caminho_completo_arquivo'] = $dados_arquivo['full_path'];
            $transacao_arquivo['is_image'] = $dados_arquivo['is_image'];
            $transacao_arquivo['extensao'] = $dados_arquivo['file_ext'];

            if ($this->Transacao_Arquivo->save($transacao_arquivo)) {
                exit(
                        "<script>"
                        . "alert('Comprovante enviado com sucesso, iremos analisar o mais rápido possivel.');"
                        . "window.close();"
                        . "</script>"
                );
            }
        }
    }

    function remove_upload($id = null) {

        $this->load->model("Transacao_Arquivo_Model", "Transacao_Arquivo");

        $user = $this->session->userdata;

        if ($this->Transacao_Arquivo->remove($id, $user['id'])) {
            exit(
                    "<script>"
                    . "alert('Arquivo removido com sucesso!');"
                    . "window.close();"
                    . "</script>"
            );
        }
    }

}
