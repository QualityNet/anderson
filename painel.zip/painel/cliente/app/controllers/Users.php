<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/*
* @property User_Model $User
*/
class Users extends MY_Controller{
    
    
    function index(){
                
        $dados_topo["subtitulo"] = "Users";
        $dados_view["corpo"] = "teste";
        
               
        $this->load->view("Comum/Comum.topo.php", $dados_topo);
        $this->load->view("Users/Users.index.php",$dados_view);
        $this->load->view("Comum/Comum.rodape.php");
    }     
    
}