<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class MY_Model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    /*
     * Anti Inject SQL
     */

    public function _antiSqlInject($value = null) {

        $sanitizeRules = array(' OR ', ' OR', 'FROM', 'SELECT', 'INSERT', 'DELETE', 'WHERE', 'DROP TABLE', 'SHOW TABLES', ' *', '--', '<SCRIPT>', '<script>', '</SCRIPT>', '</script>');

        if (is_array($value)) {
            $value = $this->_antiSqlInjectArray($value);
        } else {
            $value = (!get_magic_quotes_gpc()) ? addslashes(str_ireplace($sanitizeRules, "", $value)) : str_ireplace($sanitizeRules, "", $value);
        }
        return $value;
    }

    private function _antiSqlInjectArray($Target = null) {

        $sanitizeRules = array(' OR ', ' OR', 'FROM', 'SELECT', 'INSERT', 'DELETE', 'WHERE', 'DROP TABLE', 'SHOW TABLES', ' *', '--', '<SCRIPT>', '<script>', '</SCRIPT>', '</script>');


        foreach ($Target as $key => $value) {

            if (is_array($value)) {
                $arraSanitized[$key] = $this->_antiSqlInject($value);
            } else {
                $arraSanitized[$key] = (!get_magic_quotes_gpc()) ? addslashes(str_ireplace($sanitizeRules, "", $value)) : str_ireplace($sanitizeRules, "", $value);
            }
        }

        if (isset($arraSanitized)) {
            return $arraSanitized;
        }
    }
    
  

}
