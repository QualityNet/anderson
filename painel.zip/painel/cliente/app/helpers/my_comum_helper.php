<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/*
 * 
  array(2) {
  [0]=>
  array(1) {
  ["name"]=>
  string(5) "claro"
  }
  [1]=>
  array(1) {
  ["name"]=>
  string(3) "ceu"
  }
  }
 */

function arrayToString($separador = null, $array = null, &$retorno = null) {


    if (!is_array($array)) {
        if (is_null($retorno)) {
            return $array;
        }
        return $separador . $array;
    }

    foreach ($array as $valor) {
        $retorno .= arrayToString($separador, $valor, $retorno);
    }
}

/*function arrayToString_V2($separador = null, $array = null) {

    static $i = 0;
    $i++;
    
    $str = "";

    if (is_array($array)) {
        foreach ($array as $valor) {
            $str .= arrayToString_V2($separador, $valor);
        }
    } else {
        return $separador . $array . "($i)";
    }
    
   
    
}*/

function debug($var = null) {
    echo "<pre>";
    var_dump($var);
    echo "</pre>";
}
