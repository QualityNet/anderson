<?php

function dataBr($data = '0000-00-00 00:00:00') {
    $aux = explode(' ', $data); // $aux[0] = 0000-00-00; $aux[1] = 00:00:00
    $aux1 = explode('-', $aux[0]); // $aux1[0] = 0000; $aux1[1] = 00; $aux1[2] = 00
    $databr = $aux1[2] . "/" . $aux1[1] . "/" . $aux1[0] . " " . $aux[1];
    return $databr;
}

function dataUs($data = '00/00/0000 00:00:00') {
    $aux = explode(' ', $data); // $aux[0] = 0000-00-00; $aux[1] = 00:00:00
    $aux1 = explode('/', $aux[0]); // $aux1[0] = 00; $aux1[1] = 00; $aux1[2] = 0000
    $dataus = $aux1[2] . "-" . $aux1[1] . "-" . $aux1[0] . " " . $aux[1];
    return $dataus;
}

?>
