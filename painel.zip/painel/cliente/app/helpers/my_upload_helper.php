<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class upload {

    public function __construct() {
        
    }

    //$transacao['nome_arquivo_salvo'], $transacao['nome_arquivo_orig']
    /*
     *  <td><?= anchor($this->config->config['base_url_painel'] . 'uploads/' . $transacao['nome_arquivo_salvo'], $transacao['nome_arquivo_orig'], array('class'=>'mostra-comprovante')) ?> X</td>
      <td><?= anchor("upload/index/" . $transacao['id'], "Anexar Arquivo", array('class' => 'anexar-arquivo')) ?></td>
     */
    public static function mostraUpload($url_base = null, $nome_arquivo_salvo = null, $nome_arquivo_orig = null, $caminho_arquivo = null, $id_transacao = null, $id_arquivo = null) {

        if (null === $id_transacao) {
            exit();
        }

        if (null === $nome_arquivo_salvo || !file_exists($caminho_arquivo)) {
            return anchor("upload/index/" . $id_transacao, "Anexar Arquivo", array('class' => 'anexar-arquivo'));
        }

        return anchor($url_base . 'uploads/' . $nome_arquivo_salvo, $nome_arquivo_orig, array('class' => 'mostra-comprovante','title'=>'Visualizar')) . "&nbsp;&nbsp;" . anchor("upload/remove_upload/" . $id_arquivo, '<img src="' . $url_base . 'images/delete.png" title="Remover Arquivo"/>', array('class' => 'remover-arquivo'));
    }

}
