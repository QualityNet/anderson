<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Profile_Model extends MY_Model {

    private $tabela = "cmum_profiles";

    function getProfilesBySerialize($profiles_serizalie = null) {

        if (null === $profiles_serizalie || $profiles_serizalie === "") {
            return false;
        }

        $profiles_id_array = unserialize($profiles_serizalie);
        $profiles_id_str = implode(",", $profiles_id_array);

        $rs = $this->db->query(sprintf("SELECT name FROM %s WHERE ID IN(%s)", $this->tabela, $profiles_id_str));

        if ($rs->num_rows() > 0) {
            return $rs->result_array();
        }

        return false;
    }

}
