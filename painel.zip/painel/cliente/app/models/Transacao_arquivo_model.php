<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Transacao_Arquivo_Model extends MY_Model {

    private $tabela = 'cmum_transacao_arquivo';

    function save($dados = null) {
        if ($this->db->insert($this->tabela, $this->_antiSqlInject($dados))) {
            return true;
        }
        return false;
    }

    function getById($id = null) {
        if (null === $id) {
            exit();
        }

        $rs = $this->db->query(sprintf("SELECT * FROM %s WHERE id = %d", $this->tabela, $this->_antiSqlInject($id)));

        if ($rs->num_rows()) {
            return $rs->row_array();
        }
        return false;
    }

    function remove($id = null, $id_login = null) {
        if (null === $id || null === $id_login) {
            exit();
        }


        $transacao_arquivo = $this->getById($id);

        if (isset($transacao_arquivo['id']) && intval($transacao_arquivo['id_login']) === intval($id_login)) {

            //remove arquivo do diretorio, pode ser não o local ideal mas a tarefa é feita

            unlink($transacao_arquivo['caminho_completo_arquivo']);

            if ($this->db->delete($this->tabela, array('id' => $this->_antiSqlInject($id)))) {
                return true;
            }
        }

        return false;
    }

}
