<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class User_Model extends MY_Model {

    private $tabela = "cmum_udb";

    function getAll() {

        $rs = $this->db->query(sprintf("SELECT * FROM %s", $this->tabela));

        if ($rs->num_rows() > 0) {
            return $rs->result();
        }
        return false;
    }

    function getById($id = null) {

        $rs = $this->db->query(sprintf("SELECT * FROM %s WHERE id = %d", $this->tabela, $id));

        if ($rs->num_rows() > 0) {
            return $rs->row();
        }
        return false;
    }

    function getByLoginPass($login = null, $senha = null) {

        $rs = $this->db->query(sprintf("SELECT id,added,name,expiredate,profiles,valor_cob,addedby FROM %s WHERE name = '%s' AND password = '%s'", $this->tabela, $this->_antiSqlInject($login), $this->_antiSqlInject($senha)));

        if ($rs->num_rows() > 0) {
            return $rs->row_array();
        }
        return false;
    }
    

}
