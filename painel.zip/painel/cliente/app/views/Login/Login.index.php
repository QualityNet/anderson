<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$titulo = "Area Cliente - Entrar";
?>
<!DOCTYPE html>
<html>
    <head>	
        <title><?= $titulo ?></title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">
        <script src="<?= $this->config->config['base_url_painel'] ?>js/jquery-1.11.2.min.js" ></script>
    </head>
    <body>        
        <div class="container container-fluid">
            <div class="col-sm-4 col-sm-offset-4" id="div-login" style="border: solid 0px red">
                <?= $this->session->flashdata('msg') ?>
                <fieldset>
                    <form role="form" action="<?= base_url('index.php/login/logar') ?>" method="post">
                        <legend>Area Cliente</legend>
                        <div class="form-group">
                            <input type="text" class="form-control" name="login" placeholder="Login"/>                        
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-control" name="password" placeholder="Senha"/>                        
                        </div>                        
                        <div class="form-group">
                            <button class="btn btn-primary">Entrar</button>                 
                        </div>
                    </form>
                </fieldset>
                <hr/>
                <p style="text-align: right; font-size: 8pt"><a href="<?= $this->config->config['base_url_painel'] ?>index.php">AREA REVENDEDOR&nbsp;<span class="glyphicon glyphicon-share-alt"></span></p>
            </div>
        </div>
        <script src="<?= $this->config->config['base_url_painel'] ?>js/plugins_jquery.js"></script>
        <script>

            $(document).ready(function () {
                $("#div-login").Vcentralize();

                //centralizando ao redimensionar a tela.
                window.onresize = function () {
                    $("#div-login").Vcentralize();
                };
            });
        </script>
    </body>
</html>
