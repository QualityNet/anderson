<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$user = $this->session->userdata;
?>
<div class="div-pagamento">
    <h4>Novo Pagament1o:</h4>
    <form action="<?= base_url('index.php/transacao/save_transacao'); ?>" method="post"> 
        <div class="form-group">
            <label>Valor cobrado mensal:</label>
            <input type="text" class="form-control" name="valor_cobrado_login" id="valor_cobrado_login" readonly="true" value="<?= $user['valor_cob'] ?>">
        </div>
        <div class="form-group">
            <label>Quantidade de Meses:</label>
            <select name="qtd_meses" class="form-control" id="qtd_meses">
                <option value="1">1 Mês</option>
                <option value="2">2 meses</option>
                <option value="3">3 Meses</option>
                <option value="4">4 Meses</option>
                <option value="5">5 Meses</option>
                <option value="6">6 Meses</option>
                <option value="7">7 Meses</option>
                <option value="8">8 Meses</option>
                <option value="9">9 Meses</option>
                <option value="10">10 Meses</option>
                <option value="11">11 Meses</option>
                <option value="12">12 Meses</option>
            </select>
        </div>
        <div class="form-group">
            <label>Total Pagamento:</label>
            <input type="text" readonly="true" value="0.0" name="total_pag" id="total_pag" class="form-control"/>
        </div>
        <div class="form-group">
            <label>Tipo de Renovação</label>
            <select name="tipo_renovacao" id="tipo_renovacao" class="form-control">
                <option value="1">Pagseguro</option>
                <option value="2">Boleto Fácil</option>
                <option value="3">Depóstio/TEV</option>           
            </select>
        </div>
        <div id="div_dados_extras" style="display: none">
            <div class="form-group">
                <label>Nome ou Fantasia:</label>
                <input type="text" value="" name="nome_fantasia" id="nome_fantasia" class="form-control"/>
            </div>
            <div class="form-group">
                <label>CPF/CNPJ</label>&nbsp;<input type="checkbox" name="is_cpnj" id="is_cpnj"/>&nbsp;<span style="font-size: 8pt">CNPJ?</span>
                <input type="text" value="" name="cpf_cnpj" id="cpf_cnpj" class="form-control"/>
            </div>
        </div>
        <div class="form-group">
            <button class="btn btn-success">Iniciar Pagamento</button>                
        </div>
    </form>
</div>
<script src="<?= $this->config->config['base_url_painel'] ?>js/maskedinput.js"></script>
<script>
    function atualizaValorTotal() {

        var valor_cobrado_login = $('#valor_cobrado_login').prop('value');
        var qtd_meses = $('#qtd_meses').prop('value');
        var valor_total = parseFloat(valor_cobrado_login) * parseInt(qtd_meses);
        $('#total_pag').val(valor_total.toFixed(2));
    }

    $(document).ready(function () {

        //atualiza valor total
        atualizaValorTotal();

        $('#qtd_meses').on('change', this, function () {

            atualizaValorTotal();

        });

        var state_tr = parseInt($('#tipo_renovacao').val());

        //boleto facil mostra dados extras
        if (state_tr === 2) {

            $('#div_dados_extras').css('display', 'block');

        } else {

            $('#div_dados_extras').css('display', 'none');

        }

        $('#tipo_renovacao').on('change', this, function () {

            var state_tr = parseInt($(this).val());

            //boleto facil mostra dados extras
            if (state_tr === 2) {

                $('#div_dados_extras').css('display', 'block');

            } else {

                $('#div_dados_extras').css('display', 'none');

            }

        });

        // inicia com a mascara de cpf
        var state = $('#is_cpnj').is(':checked') ? 1 : 0;

        if (state === 1) {

            $("#cpf_cnpj").mask("99.999.999/9999-99");

        } else {

            $("#cpf_cnpj").mask("999.999.999-99");

        }

        $('#is_cpnj').on('click', function () {

            var state = $(this).is(':checked') ? 1 : 0;

            if (state === 1) {

                $("#cpf_cnpj").mask("99.999.999/9999-99");

            } else {

                $("#cpf_cnpj").mask("999.999.999-99");

            }

        });


    });
</script>
