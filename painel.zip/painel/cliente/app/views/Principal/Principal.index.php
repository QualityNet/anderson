<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 * 
 * 
 * @property CI_Session $session
 */

$user = $this->session->userdata;
?>
<div class="div-princ-index">
    <!-- Div detalhes conta -->
    <div class="row">
        <div class="col-sm-6">
            <h3>Detalhes da Conta</h3>
            <p style="font-size: 8pt">
                <strong>Data de Cadastrado:</strong>&nbsp;<?= date('d/m/Y H:i:s', strtotime($user['added'])); ?><br/>
                <strong>Vencimento:</strong>&nbsp;<?= date('d/m/Y H:i:s', strtotime($user['expiredate'])); ?><br/>
                <strong>Perfis:</strong>&nbsp;<?= $user['profile_string']; ?><br/>
            </p>
        </div>
        <div class="col-sm-6">
            <h3 class="text-right">
                <a href="<?= base_url('index.php/principal/add_pagamento'); ?>" class="btn btn-success janela-popup" target="_blank">Novo Pagamento</a>               
            </h3>           
        </div>
    </div>

    <div class="panel panel-default ">
        <!-- Default panel contents -->
        <div class="panel-heading">Transações</div>
        <!-- Table -->
        <div class="table-responsive">
            <table class="table" style="font-size: 8pt">
                <thead>
                <th></th>
                <th>ID Transação</th>
                <th>Data Inicio</th>
                <th>Tipo</th>
                <th>Status</th>
                <th>Ultima Atualizacao</th>
                <th>Observação</th>

                </thead>
                <tbody>
                    <?php
                    if (count($transacoes) > 0 && $transacoes !== false) {
                        foreach ($transacoes as $transacao) {
                            $adapter_trans->setTransacao($transacao);
                            ?>
                            <tr>

                                <td>
                                    <?php if ($transacao['status'] == '1' || $transacao['status'] == '2'): ?>
                                        <?= upload::mostraUpload($this->config->config['base_url_painel'], $transacao['nome_arquivo_salvo'], $transacao['nome_arquivo_orig'], $transacao['caminho_completo_arquivo'], $transacao['id'], $transacao['id_arquivo']); ?>
                                    <?php endif; ?>
                                </td>
                                <td>#<?= $transacao['id'] ?></td>
                                <td><?= $adapter_trans->getDataCad_BR(); ?></td>
                                <td><?= $adapter_trans->getTipoString(); ?></td>
                                <td><?= $adapter_trans->getStatusString(); ?></td>
                                <td><?= $adapter_trans->getDataAtualizacao_BR(); ?></td>
                                <td><?= $transacao['detalhes']?></td>
                            </tr>
                            <?php
                        }
                    } else {
                        ?>
                        <tr>
                            <td colspan="6">Dados não encontrados ou não atendem aos parametros de pesquisa.</td>
                        </tr>
                    <?php } ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="7"><?= $page_links ?></td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
</div>
<script src="<?= $this->config->config['base_url_painel'] ?>js/plugins_jquery.js"></script>
<script>
    /*$('.janela-popup').janelaCentro({
        w: '800',
        h: '600r '
    });*/
    $('.anexar-arquivo').janelaCentro({
        w: '400',
        h: '300'
    });
    $('.mostra-comprovante').janelaCentro({
        w: '800',
        h: '600'
    });
    $('.remover-arquivo').janelaCentro({
        w: '400',
        h: '200',
        confirma: function () {
            return confirm("Deseja mesmo remover este arquivo ?");
        }
    });
</script>
