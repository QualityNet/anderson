<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<h4>Anexar Imagem</h4>
<form method="post" enctype="multipart/form-data" action="<?= base_url("index.php/upload/save_upload"); ?>">
    <input type="hidden" name="transacao_id" value="<?= $transacao_id ?>"/>
    <div class="form-group">
        <?= $this->session->flashdata('msg') ?>
        <label>Selecione:</label>
        <input type="file" name="userfile" class="form-control"/>
        <desc style="font-size: 8pt">* Tipos permitidos: <strong>(gif|jpg|png|pdf)</strong></desc>
        <desc style="font-size: 8pt">/ Tamanho máximo: <strong>(2 mb)</strong></desc>
    </div>
    <div class="form-group">
        <button class="btn btn-success">Anexar</button>
    </div>
</form>

