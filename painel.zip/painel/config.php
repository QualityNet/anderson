<?php

// debugando erros
$debug = "0";

// variaveis de conexão

$dbhost = "localhost";
$dbname = "painel";
$dbuser = "root";
$dbpass = "anderson03868439021+A@29041995";
$charset = "utf-8";

//configurações globais
$config['base_url'] = 'http://52.67.24.181//painel/';

