<?php 
//require_once ("config.php");
$admId = $_SESSION["adminid"];
$level = $_SESSION["adminlevel"];
$loguntil = 10;
$nologs = "None";
$failedloginlog = "10 Latest Failed Login Attempts";
if (isset($_POST["sublogshowall"]) and $_POST["sublogshowall"] == "Show all") {
    $loguntil = 0;
    $failedloginlog = "All Failed Login Attempts";
}
if (isset($_POST["sublogclear"]) and $_POST["sublogclear"] == "Clear logs") {
    $conn = @mysql_connect($dbhost, $dbuser, $dbpass) or sqlerror();
    mysql_select_db($dbname, $conn);
    $sql = mysql_query("TRUNCATE TABLE cmum_failedlogins");
    mysql_close($conn);
    $nologs = "Logs cleard!";
};
$agora = date('Y-m-d H:i:s');
$conn = @mysql_connect($dbhost, $dbuser, $dbpass) or sqlerror();
mysql_select_db($dbname, $conn);
$sql = mysql_query("SELECT * FROM cmum_udb where addedby='$admId'");
$rowcheckA = mysql_num_rows($sql);
$sql = mysql_query("SELECT * FROM cmum_udb WHERE addedby='$admId' AND enabled='true' AND expiredate > '{$agora}'");
$rowcheckE = mysql_num_rows($sql);
$sql = mysql_query("SELECT * FROM cmum_udb WHERE addedby='$admId' AND enabled='false'");
$rowcheckD = mysql_num_rows($sql);
$sql = mysql_query("SELECT * FROM cmum_udb WHERE addedby='$admId' AND enabled='true' AND expiredate < '{$agora}'");
$rowcheckV = mysql_num_rows($sql);
$sql = mysql_query("SELECT * FROM cmum_admins WHERE level='0'");
$rowcheckAdm = mysql_num_rows($sql);
$sql = mysql_query("SELECT * FROM cmum_admins WHERE level='1'");
$rowcheckRev = mysql_num_rows($sql);
mysql_close($conn);
//echo "<div class='alert alert-success'>Logins cadastrados: (" . $rowcheckA . ") Logins ativos: (" . $rowcheckE . ") Logins desativados: (" . $rowcheckD . ") Logins vencidos: ({$rowcheckV}) Admins: (" . $rowcheckAdm . ") Revendas: (" . $rowcheckRev . ")</div>";;
?>