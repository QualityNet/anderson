<?php
require ("includes/logincheck.php");
require ("includes/debug.php");
require ("config.php");
require ("func_estatisticas.php");
require ("includes/functions.php");
require ("includes/settings.php");
$admId = $_SESSION["adminid"];
$level = $_SESSION["adminlevel"];
$qtd_logins_perfis = $_SESSION['_qtd_logins_perfis'];
$rev_pre = $_SESSION['rev_pre'];
$pf_pm = unserialize($_SESSION["_profiles_pm"]);
if (is_null($pf_pm)) {
    $pf_pm = array();
}
if (isset($_GET['carregar_notif'])) {
    $id_rev = $_SESSION['adminid'];
    $conn = @mysql_connect($dbhost, $dbuser, $dbpass) or sqlerror();
    mysql_select_db($dbname, $conn);
    $arvore = arvoreRevendasLista();
    $ids_em_arvore = array();
    arrayListaRevenda($id_rev, $arvore, 1, $ids_em_arvore);
    $ids_em_arvore_str = implode(',', $ids_em_arvore);
    $SQL = "SELECT * FROM cmum_notificacoes_interna AS n1 " . "WHERE (id_para_rev = 0 OR id_para_rev='{$id_rev}' OR (id_para_rev IN ($ids_em_arvore_str) AND propagar_subrev=1)) AND NOT EXISTS (" . "SELECT n2.id_notificacao FROM cmum_notif_int_lidas AS n2 " . "WHERE n2.id_notificacao=n1.id AND id_revenda='{$id_rev}') ORDER BY n1.id ASC";
    $rs = mysql_query($SQL);
    $notificacoes = array();
    if (mysql_num_rows($rs) > 0) {
        $notificacoes = mysql_fetch_assoc($rs);
        echo json_encode($notificacoes);
    } else {
    }
    exit();
}
if (isset($_GET['confirma_leitura'])) {
    $id_notificacao = $_POST['id_notif'];
    $id_revenda = $_SESSION['adminid'];
    $conn = @mysql_connect($dbhost, $dbuser, $dbpass) or sqlerror();
    mysql_select_db($dbname, $conn);
    $SQL = "INSERT INTO cmum_notif_int_lidas (" . "id," . "id_revenda," . "id_notificacao) VALUES(" . "null," . "'{$id_revenda}'," . "'{$id_notificacao}')";
    $rs = mysql_query($SQL);
    if ($rs === true) {
        $ret['sucesso'] = 1;
        echo json_encode($ret);
    }
    exit();
}
if (isset($_GET['info_perf']) && is_numeric($_GET['info_perf'])) {
    $id_perf = $_GET['info_perf'];
    $conn = @mysql_connect($dbhost, $dbuser, $dbpass) or sqlerror();
    mysql_select_db($dbname, $conn);
    $SQL = "SELECT * FROM cmum_profiles WHERE id='{$id_perf}'";
    $rs = mysql_query($SQL);
    if (mysql_num_rows($rs) > 0) {
        $ret['perf'] = mysql_fetch_assoc($rs);
        echo json_encode($ret);
    }
    exit();
};
?>
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=<?php print($charset); ?>" />
        <title>:: <?php print($longtitle); ?></title>
        <link rel="shortcut icon" href="favicon.ico"/>
        <link rel="apple-touch-icon" href="favicon.png"/>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
            <link href="css/main.css" rel="stylesheet" type="text/css" />
            <script src="http://code.jquery.com/jquery-1.11.1.js"></script>
            <script src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
            <script language="JavaScript">
                function onlyNumbers(evt)
                {
                    var e = event || evt; // for trans-browser compatibility
                    var charCode = e.which || e.keyCode;

                    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
                        return false;
                    }

                    return true;
                }
                function teste_key(campo) {
                    alert(campo.value);
                }
            </script>
            <style>
                .vertical{
                    writing-mode:tb-rl;
                    -webkit-transform:rotate(270deg);
                    -moz-transform:rotate(270deg);
                    -o-transform: rotate(270deg);
                    white-space:nowrap;
                    display:block;
                    bottom:0;
                    width:20px;
                    height:20px;
                    margin-top: 15px
                }
                .pref-titulo-urls{
                    cursor: pointer;
                }
            </style>
    </head>

    <body style="">                    
 <?php require_once 'topo.php';?>
 
 <div style="width: 1000px; margin: auto; margin-top: 10px">
  
<div class="row"  align="center" style="margin: auto; margin-top: 10px">
<div class="col-sm-9" style="width:1000px">
          <div class="panel panel-primary">
            <div class="panel-heading">
              <h4 class="panel-title" align="left">Menu</h4>
            </div>
            <div class="panel-body" align="left">

 <table width="100%" max-width="100%" margin-bottom= "0px"  border-spacing="0"  border-collapse="collapse" align="center" valign="top" border="0" cellspacing="0" cellpadding="0" id="tabMenu">
           <tr bgcolor="">
                    <td style="text-align: center">
						<a href="adduser.php" class="thumbnail">
                        <img src="images/add-user2.png" alt="Cadastrar Logins" title="Cadastrar Logins" width="43px" height="43px">
                            <p style="text-align: center">ADICIONAR LOGIN</p>
                    </a>
                    </td>
                    
					<td style="text-align: center">
                         <a href="manusers.php" class="thumbnail">
                        	<img src="images/gerencia_user.png" alt="Gerenciar Logins"  title="Gerenciar Logins" width="43px" height="43px">
                            <p style="text-align: center">GERENCIAR LOGINS</p>
                    	 </a>
                    </td>               
               
 					<td style="text-align: center">
                    	<a href="useronline.php" class="thumbnail">
                        <img src="images/online.png" alt="Logins Online"  title="Logins Online" width="43px" height="43px">
                            <p style="text-align: center">LOGINS ONLINE</p>
                    	</a>
                    </td>
 
                     <td style="text-align: center">
                    	<a href="admins.php" class="thumbnail">
                        <img src="images/revendas.png" alt="Cadastrar Revendas"  title="Cadastrar Revendas"  width="43px" height="43px">
                            <p style="text-align: center">REVENDAS</p>
                    	</a>
                    </td>        


                    <td style="text-align: center">
                    <a href="settings.php" class="thumbnail">
                        <img src="images/options.png" alt="Op��es"  title="Opcoes" width="43px" height="43px">
                            <p style="text-align: center">OPCOES</p>
                    </a></td> 

                    <td style="text-align: center">
                    <a href="tools.php" class="thumbnail">
                        <img src="images/tools.png" alt="Ferramentas"  title="Ferramentas"  width="43px" height="43px">
                            <p style="text-align: center">FERRAMENTAS</p>
                    </a>
                    </td>

                    <td style="text-align: center">
                    <a href="opcoes_relatorios.php" class="thumbnail">
                        <img src="images/relatorios.png" alt="Op��es Relat�rios" title="Opcoes Relatorios" width="43px" height="43px">
                            <p style="text-align: center"> RELATORIOS</p>
                    </a>
                    </td>
                    
                    <td style="text-align: center">
                    <a href="emails_notificacoes.php" class="thumbnail">
                        <img src="images/mailvenc.png" alt="Enviar emails e notifica��es." title="Enviar emails e notificacoes." width="43px" height="43px">
                            <p style="text-align: center"> NOTIFICACOES</p>
                    </a>
                    </td>                    

                <tr bgcolor="">
                    <td colspan="1"></td>
                </tr>
                

                    <td style="text-align: center">
                    <a href="falha_logins_todos.php" class="thumbnail">
                        <img src="images/falhas_login.png" alt="Falha Logins no Servidor" title="Falha Logins no Servidor" width="43px" height="43px">
                            <p style="text-align: center">LOGINS COM FALHAS</p>
                    </a>
                    </td>  
                    
                    <td style="text-align: center">
                    <a href="urls.php" class="thumbnail">
                        <img src="images/urls.png" alt="Urls" title="Urls" width="43px" height="43px">
                            <p style="text-align: center">URLS</p>
                    </a>
                    </td>                                    


<?php if ($level == 0):;?>

                    <td style="text-align: center">
                        <a href="profiles.php" class="thumbnail">
                            <img src="images/perfil.png" alt="Gerenciar Perfis" title="Gerenciar Perfis" width="43px" height="43px">
                                <p style="text-align: center">PERFIS</p>
                        </a>
                    </td> 

                    <td style="text-align: center">
                        <a href="estatisticas.php" class="thumbnail">
                            <img src="images/estatisticas.png" alt="Estatisticas do Painel" title="Estatisticas do Painel" width="43px" height="43px">
                                <p style="text-align: center">ESTATISTICAS</p>
                        </a>
                    </td>


<?php endif;;?>


<?php if ($level == "0" || $rev_pre == "1"):;?>

                    <td style="text-align: center">
                    <a href="prepago/index.php" class="thumbnail">
                        <img src="images/pre_pago.png" alt="Relatorios" title="menu pre pago" width="43px" height="43px">
                            <p style="text-align: center">MENU PRE-PAGO</p>
                    </a>
                    </td>


<?php endif;;?>
                    <td style="text-align: center">
                    <a href="transacoes.php" class="thumbnail">
                        <img src="images/transacoes.png" alt="Relatorios" title="transacoes" width="43px" height="43px">
                            <p style="text-align: center">TRANSACOES</p>
                    </a>
                    </td>

</tr>
</table>

           </div>
		  </div>           
       </div>    
</div>      
      
      
  

<div class="row"  align="center" style="margin: auto; margin-top: 10px">
<div class="col-sm-9" style="width:1000px">
           <div class="panel panel-info">
            <div class="panel-heading">
              <h4 class="panel-title" align="left">Teste autom&aacute;tico</h4>
            </div>
            <div class="panel-body">
			<?php if (checkar_permissao_rev($admId, "11") || $level == '0'):
    		$url_teste = url_exibivel_painel("formulario_testes.php?r=" . base64_url_encode(ept($admId, $s)));;
			?>            
<div class="row">
                <div class="container">
                    
                    <!-- valor cobrado por login-->
<?php
    if (isset($_POST['btn_sav_valor'])) {
        $valor_cobrado_global = $_POST['valor_cobrado_global'];
        if ($valor_cobrado_global > 0) {
            $con = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
            $rs = $con->query("UPDATE cmum_admins SET valor_cobrado_global = {$valor_cobrado_global}" . " WHERE id={$admId}");
        }
    }
    $dados_revenda = dados_revenda($admId, 'valor_cobrado_global');;
?>                   

<form method="post">

	<div class="form-group col-sm-4">
		<label>Valor cobrado por login:</label>&nbsp;R$&nbsp;
        <input type="number" name="valor_cobrado_global" id="valor_cobrado_global" value="<?php echo intval($dados_revenda['valor_cobrado_global']);?>"<?php if (intval($dados_revenda['valor_cobrado_global']) !== 0):;?> readonly<?php endif;;?>/>

		<?php if (intval($dados_revenda['valor_cobrado_global']) !== 0):;?>
    
        <a href="#" id="mod_valor_cob" state="0">Modificar</a>
        <input type="submit" id="btn_sav_valor" name="btn_sav_valor" value="Salvar" style="display: none"/>
      
    	<?php else:;?>
        <input type="submit" name="btn_sav_valor" value="Salvar"/>
		<?php endif;;?>
	</div>
    
    <div class="alert alert-info col-sm-3" style="font-size: 8pt">Este ser&aacute; o valor cobrado mensal quando um login solicitar o teste autom&aacute;tico.</div>
</form>
	</div>            
    </div>

<div class="col-sm-4">
  <h5>Url de pedidos de testes autom&aacute;ticos:</h5>
  </div>
  <div style="width:100%">
    <input readonly value="<?=$url_teste;?>" class="form-control" size="50" maxlength="50"/>&nbsp;<a href="<?=$url_teste;?>" target="_blank">ABRIR</a>
 </div>
<?php
endif;;
?>
           </div>

		</div>
	</div>
</div>



<!--ul>li.item$*10-->
<!-- usuario admin -->
<?php
if ($level == 0)
{?>
<div class="row"  align="center" style="width: 1000px; margin: auto; margin-top: 10px">
       <div class="col-md-6">
          <div class="panel panel-info">
            <div class="panel-heading">
              <h4 class="panel-title" align="left">Relat&oacute;rio de clientes</h4>
            </div>
            <div class="panel-body" align="left">
             <h4>Logins cadastrados: (<font color="#0B5AA3"><?=$rowcheckA?></font>) </h4>
             <h4>     Logins ativos: (<font color="#029155"><?=$rowcheckE?></font>) </h4>
             <h4>Logins desativados: (<font color="#DBCC00"><?=$rowcheckD?></font>) </h4>
             <h4>   Logins vencidos: (<font color="#FF0004"><?=$rowcheckV?></font>) </h4>
             <h4> Admins: (<?=$rowcheckAdm?>) </h4>
             <h4>Revendas: (<?=$rowcheckRev?>)</h4>
           </div>
		  </div>           
       </div>    
    <div class="col-md-6">
           <div class="panel panel-info">
            <div class="panel-heading">
              <h4 class="panel-title" align="left">Estado do servidor</h4>
            </div>
            <div class="panel-body">
			<?php require ("includes/cspsrvinfo.php");?>
           </div>

		</div>
	</div>
</div>
<?php } ?>
<!-- fecha usuario admin -->





<!-- revenda -->
<?php
if($level > 0)
{?>
<div class="row"  align="center" style="margin: auto; margin-top: 10px">
<div class="col-sm-9" style="width:1000px">
          <div class="panel panel-info">
            <div class="panel-heading">
              <h4 class="panel-title" align="left">Relat&oacute;rio de clientes</h4>
            </div>
            <div class="panel-body" align="left">
             <h4>Logins cadastrados: (<font color="#0B5AA3"><?=$rowcheckA?></font>) </h4>
             <h4>     Logins ativos: (<font color="#029155"><?=$rowcheckE?></font>) </h4>
             <h4>Logins desativados: (<font color="#DBCC00"><?=$rowcheckD?></font>) </h4>
             <h4>   Logins vencidos: (<font color="#FF0004"><?=$rowcheckV?></font>) </h4>
           </div>
		  </div>           
       </div>    
</div>
<?php }?>
<!-- fecha revenda -->







        <!-- Modal Erro -->
        <div class="modal modal-acao-notif" data-backdrop="static">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <!--<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>-->
                        <h4 class="modal-title title-notif">...</h4>
                    </div>
                    <div class="modal-body body-notif" style="text-align: center">
                        ...
                    </div>
                    <div class="modal-footer">
                        <!--<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>-->
                        <input type="hidden" id="id_notif" name="id_notif" value=""/>
                        <button type="button" class="btn btn-primary btn-conf-notif">Ok</button>
                    </div>
                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div><!-- /.modal -->
        <div class="modal modal-info-perf" data-backdrop="static">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <!--<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>-->
                        <h4 class="modal-title title-info-perf">...</h4>
                    </div>
                    <div class="modal-body body-info-perf" style="text-align: center">
                        ...
                    </div>
                    <div class="modal-footer">
                        <!--<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>-->
                        <button type="button" class="btn btn-primary btn-info-perf">Ok</button>
                    </div>
                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div><!-- /.modal -->
        <div style="clear: both">
<br />
          






<?php require("includes/footer.php"); ?>

        </div>
        <script>
            $(document).ready(function () {

                $('#mod_valor_cob').on('click', function () {

                    var state = $(this).attr('state');

                    if (state === '0') {

                        $('#valor_cobrado_global').removeAttr('readonly');
                        $(this).css('display', 'none');
                        $('#btn_sav_valor').css('display', 'inline');
                        $('#valor_cobrado_global').focus();

                    }


                });

                $.get("home.php?carregar_notif=true", function (ret) {
                    if (ret.id) {

                        var str_titulo = "N";
                        var str_mensagem = "N";

                        if (ret.tipo === "1") {

                            str_titulo = 'DICA';
                            str_mensagem = '<div class="alert alert-warning">' + ret.mensagem + '</div>';

                        }
                        if (ret.tipo === "2") {

                            str_titulo = 'INFORMATIVO';
                            str_mensagem = '<div class="alert alert-primary">' + ret.mensagem + '</div>';

                        }
                        if (ret.tipo === "3") {

                            str_titulo = 'ADVERT�NCIA';
                            str_mensagem = '<div class="alert alert-danger">' + ret.mensagem + '</div>';


                        }
                        //alert(ret.tipo);
                        $('.title-notif').html(str_titulo);
                        $('.body-notif').html(str_mensagem);
                        $('#id_notif').val(ret.id);
                        $('.modal-acao-notif').modal('show');
                    }

                }, "json");


                $('.btn-conf-notif').on('click', this, function () {
                    var _id_notif = $('#id_notif').val();
                    $.ajax({
                        type: 'POST',
                        url: 'home.php?confirma_leitura=true',
                        data: {
                            id_notif: _id_notif
                        },
                        dataType: 'json'
                    })
                            .done(function (r) {
                                //alert(r);
                                if (r.sucesso) {
                                    $('.modal-acao-notif').modal('hide');
                                    //$('.modal-conf-del').modal('hide');
                                    //$('.modal-acao-sucesso').modal('show');
                                }
                            });



                });
                $('.info-perf').on('click', this, function () {
                    var id = $(this).attr('pid');
                    $.ajax({
                        type: "GET",
                        url: "home.php?info_perf=" + id,
                        dataType: "json"
                    })
                            .done(function (r) {
                                $('.title-info-perf').html('Informa��es do perfil: ' + r.perf.name);
                                $('.body-info-perf').html(r.perf.obs);
                                $('.modal-info-perf').modal('show');
                                $('.btn-info-perf').on('click', this, function () {
                                    $('.modal-info-perf').modal('hide');
                                });
                            });



                    return false;
                });
                $('.pref-titulo-urls').on('click', this, function () {
                    state = $(this).attr('state');
                    if (state == "0") {
                        $(this).removeClass('glyphicon-step-forward');
                        $(this).addClass('glyphicon-step-backward');
                        $(this).attr('state', '1');
                        $('.urls-tudo').css('width', '250px');
                        $('.urls-tudo').css('height', '650px');
                        $('.content-urls').css('display', 'block');
                        $(this).prop('title', 'Recolher');
                    }
                    if (state == "1") {
                        $(this).removeClass('glyphicon-step-backward');
                        $(this).addClass('glyphicon-step-forward');
                        $(this).attr('state', '0');
                        $('.urls-tudo').css('width', '25px');
                        $('.urls-tudo').css('height', '100px');
                        $('.content-urls').css('display', 'none');
                        $(this).prop('title', 'Expandir');
                    }
                    return false;
                });
            });




        </script>
    </body>
</html>