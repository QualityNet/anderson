<?php 
if (@$debug == "1") {error_reporting(E_ALL);$s = "sdebug";$h = $_SERVER['SERVER_ADDR'];ini_set('display_errors', 'On');}else {error_reporting(E_ALL);$s = "sdebug";$h = $_SERVER['SERVER_ADDR'];ini_set('display_errors', 'Off');} 
?>