<div style="border: solid 0px red; width: 1000px; margin: auto">

<?php require ("includes/header.php");?>

<div class="clearfix" style="color: #fff; background:#0099FF; padding: 10px;font-size: 11pt" align="center"><?=$mensagem?>&nbsp;<a href="logout.php" style="float:right; color:#fff;"><img src="images/exit.png" width="25px" style="width: 25px"/>&nbsp;Sair</a></div>
	</div>
</div>
  